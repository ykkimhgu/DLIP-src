#include <iostream>

// Declare Function
// Add code here

int main()
{
	// Input value
	double num1 = 10.0;
	double num2 = 20.0;
	double num3 = 30.0;

	// Output value
	double numOut1; 
	double numOut2;	
	double numOut3;

	// Add code here

	// Print output value
	std::cout << numOut1 << std::endl;
	std::cout << numOut2 << std::endl;
	std::cout << numOut3 << std::endl;
}

// Define Function
// Add code here