#include "TU_DLIP.h"

#include <iostream>

// =============================
// Exercise 1 :: Define Function
// =============================

int sum(int val1, int val2)
{
	// Add code here
}

// ====================================
// Exercise 2 :: Create a Class ��myNum��
// ====================================

MyNum::MyNum(int x1, int x2)
{
	// Add code here
}

int MyNum::sum(void)
{
	// Add code here
}

void MyNum::print(void)
{
	// Add code here
}










