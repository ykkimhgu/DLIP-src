/*------------------------------------------------------/
* Image Proccessing with Deep Learning
* Cpp Tutorial: Template
* Created: 2021-Spring
------------------------------------------------------*/

#include <iostream>

namespace proj_B {
	// ADD CODE HERE
}

int main(void) {
	
	// ADD CODE HERE
	// 1) TEMPLATE AS INT 
	// 2) TEMPLATE AS DOUBLE
	// 3) PRINT RESULT

	return 0;
}