#include "TU_DLIP.h"

#include <iostream>

int main()
{
	// =============================
	// Exercise 1 :: Define Function
	// =============================

	// Add code here


	// ====================================
	// Exercise 2 :: Create a Class 'myNum'
	// ====================================

	// Add code here

}
