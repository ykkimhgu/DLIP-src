//* ------------------------------------------------------ /
//*Image Proccessing with Deep Learning
//* OpenCV : Filter Demo
//* Created : 2021 - Spring
//------------------------------------------------------ * /

#include <opencv2/opencv.hpp>
#include <iostream>

using namespace std;
using namespace cv;

void main()
{
	Mat src, dst, dst_lap;

	src = imread("../../Image/blurry_moon.tif", 0);

	namedWindow("Src", CV_WINDOW_NORMAL);
	imshow("Src", src);

	int i = 3;
	Size kernelSize = cv::Size(i, i);

	/* Blur */
	cv::blur(src, dst, cv::Size(i, i), cv::Point(-1, -1));
	namedWindow("Blur", WINDOW_NORMAL);
	imshow("Blur", dst);

	/* Gaussian Filter */
	cv::GaussianBlur(src, dst, Size(i, i), 0, 0);
	namedWindow("Gaussian", WINDOW_NORMAL);
	imshow("Gaussian", dst);


	/* Median Filter */
	cv::medianBlur(src, dst, i);
	namedWindow("Median", CV_WINDOW_AUTOSIZE);
	imshow("Median", dst);

	/* Bilateral Filter */
	int p = 3;
	bilateralFilter(src, dst, p, p * 2, p / 2);
	namedWindow("Bilateral", CV_WINDOW_AUTOSIZE);
	imshow("Bilateral", dst);

	/* Laplacian Filter */
	int kernel_size = 3;
	int scale = 1;
	int delta = 0;
	int ddepth = CV_16S;

	cv::Laplacian(src, dst, ddepth, kernel_size, scale, delta, cv::BORDER_DEFAULT);
	src.convertTo(src, CV_16S);
	cv::Mat result_laplcaian = src - dst;
	result_laplcaian.convertTo(result_laplcaian, CV_8U);
	namedWindow("Laplacian", CV_WINDOW_AUTOSIZE);
	cv::imshow("Laplacian", result_laplcaian);

	/* 2D Convolution of a filter kernel */
	/* Design a normalized box filter kernel 5 by 5 */
	src.convertTo(src, CV_8UC1);

	Mat kernel;
	delta = 0;
	ddepth = -1;
	kernel_size = 3;
	Point anchor = Point(-1, -1);

	//kernel = Mat::ones(kernel_size, kernel_size, CV_32F) / (float)(kernel_size * kernel_size);
	kernel = {
		 0, -1,  0,
		-1,  4, -1,
		 0, -1,  0 };

	cv::filter2D(src, dst, ddepth, kernel, anchor);
	namedWindow("Conv2D", CV_WINDOW_AUTOSIZE);
	cv::imshow("Conv2D", dst);
	
	dst_lap = src + dst;
	namedWindow("Conv2D_lap", CV_WINDOW_AUTOSIZE);
	cv::imshow("Conv2D_lap", dst_lap);

	cv::waitKey(0);
}