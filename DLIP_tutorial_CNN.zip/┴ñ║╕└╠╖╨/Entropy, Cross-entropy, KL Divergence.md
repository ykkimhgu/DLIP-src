# 정보이론: Entropy, Cross-entropy, KL Divergence



## 학습목표

- 정보량, Entropy, Cross-entropy, KL Divergence의 이해



## 정보량

### 들어가며

- 아래 두 경우 중 어떤 것이 더 유용한 정보라 판단되는가? 그 이유는 무엇인가?
  - 이번 주 채플은 평소처럼 수요일에 열린대! (평이한 상황)
  - 이번 주 채플이 금요일로 바뀌었대! (일반적이지 않은 상황)
- 정보량은 확률의 희소성과 비례한다는 의견에 동의하는가? 맞다면, 이것을 정량적인 수치로 표현할 수 있을까?



### 의미

- 확률변수 x을 관측 시 얻게 되는 정보의 정량적 지표 (0~1로 표현)

- 놀람의 정도(degree of surprise) : 낮은 확률의 사건 발생시 높은 정보량 획득

  - 확률함수-정보량 관계는 단조감소 함수 (높은 확률일수록 정보량 ↓)
  - 따라서, x의 정보량 h(x)는 x의 확률함수 p(x)에 대한 함수 f {·}로 표현 가능함

  $$
  h(x) = f\{ p(x)\}
  $$


### f{·} 찾기

- 독립확률변수 x, y가 있다고 가정

- 두 변수에 대한 정보가 동시에 들어왔을 때, 정보량은 각 변수별 정보량의 합으로 표현 가능함
  $$
  h(x,y) = h(x) + h(y)
  $$
  
- 또한, 독립확률변수의 성질에 의해 아래 식이 성립함
  $$
  p(x,y) = p(x) \cdot p(y)
  $$

- 이 둘을 조합하면 아래와 같음

$$
\eqalign{
  & h(x,y) = h(x) + h(y) = f\{ p(x)\}  + f\{ p(y)\}   \cr 
  & \,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\, = f\{ p(x,y)\} \,\,\,\, = f\{ p(x) \cdot p(y)\}  \cr}
$$

- 각 줄 우측항의 등식이 성립하고, [0, 1] 범위의 단조감소함수 f {·}를 만족하는 함수는 -log 임

$$
f\{  \cdot \}  =  - \log _a \{  \cdot \}
$$

- 따라서, 확률변수 x의 정보량은 아래 수식과 같이 정의됨

$$
h(x) = f\{ p(x)\}  =  - \log _a p(x)
$$





## Entropy

### 의미 및 특징

- 변수 x의 정보의 기대값: 평균 정보량

$$
H[x] = E_p [h(x)] = E_p [ - \log _a p(x)] =  - \sum\nolimits_x {p(x)\log _a p(x)}
$$

- 이산확률변수에서는 주로 a=2로, 연속확률변수에서는 주로 a=e(자연로그의 밑)로 사용됨

  - 이산확률변수
    - a=2로 활용시 정보량의 단위는 [bit]가 됨
    - 엔트로피가 최대가 되기 위해서는, 분포가 uniform 해야함 (아래 예제 참조)
    - 엔트로피가 최소가 되기 위해서는, 한 사건에 발생확률이 몰려있음 → 엔트로피가 0이 됨
    - 엔트로피는 변수 x를 전송하는 데 필요한 평균 코드 길이의 lower bound (최적 정보량)

  $$
  H[x] = E_p [h(x)] = E_p [ - \log _2 p(x)] =  - \sum\nolimits_x {p(x)\log _2 p(x)\,\,\,[\rm{bit}]}
  $$

  - 연속확률변수

    - a=e 인 경우 정보량의 단위는 [nat]이 됨
    - 엔트로피가 최대가 되기 위해서는, 가우시안 분포를 따라야 함
    - 엔트로피가 최소가 되기 위해서는, 한 사건에 발생확률이 몰려있음 → 엔트로피가 0이 됨

    $$
    H[x] = E_p [h(x)] = E_p [ - \log _2 p(x)] =  - \int_x {p(x)\ln p(x)dx\,\,\,[{\rm{nat}}]}
    $$

    


### 예제

#### Q1. 아래와 같이 상자 안에 8개의 공이 있고, 공의 색깔을 변수로 둘 때 엔트로피를 구하시오

![](./images/entropy_Q1.png)

#### solution) 

$$
\eqalign{
  & H[x]{\rm{ =  - p(red)log}}_2 {\rm{p(red) - p(yellow)log}}_2 {\rm{p(yellow) - p(green)log}}_2 {\rm{p(green) - p(blue)log}}_2 {\rm{p(blue)}}  \cr 
  & \,\,\,\,\,\,\,\,\,\,\,\,\, =  - {1 \over 4}\log ({1 \over 4}) - {1 \over 4}\log ({1 \over 4}) - {1 \over 4}\log ({1 \over 4}) - {1 \over 4}\log ({1 \over 4}) = {1 \over 2} + {1 \over 2} + {1 \over 2} + {1 \over 2} = 2\,[\rm{bit}]  \cr 
  &  \cr}
$$

​												▶ 빨강,노랑,초록,파랑 순서대로 (00, 01, 10, 11)로 인코딩 가능 (2 [bit]) 



#### Q2. 아래와 같이 상자 안에 8개의 공이 있고, 공의 색깔을 변수로 둘 때 엔트로피를 구하시오

![](./images/entropy_Q2.png)

#### solution) 

$$
\eqalign{
  & H[x]{\rm{ =  - p(red)log}}_2 {\rm{p(red) - p(yellow)log}}_2 {\rm{p(yellow) - p(green)log}}_2 {\rm{p(green) - p(blue)log}}_2 {\rm{p(blue)}}  \cr 
  & \,\,\,\,\,\,\,\,\,\,\,\,\, =  - {1 \over 2}\log ({1 \over 2}) - {1 \over 4}\log ({1 \over 4}) - {1 \over 8}\log ({1 \over 8}) - {1 \over 8}\log ({1 \over 8}) = {1 \over 2} + {1 \over 2} + {3 \over 8} + {3 \over 8} = 1.75\,[\rm{bit}]  \cr 
  &  \cr}
$$

​												▶ 빨강,노랑,초록,파랑 순서대로 (00, 01, 10, 11)로 인코딩 가능 (2 [bit])

​												▶ 최적인코딩: 빨강,노랑,초록,파랑 순서대로 (0, 10, 100, 101)로 인코딩 (1.75 [bit])



#### Q3. 아래와 같이 상자 안에 8개의 공이 있고, 공의 색깔을 변수로 둘 때 엔트로피를 구하시오

![](./images/entropy_Q3.png)

#### solution) 

$$
\eqalign{
  & H[x]{\rm{ =  - p(red)log}}_2 {\rm{p(red) - p(yellow)log}}_2 {\rm{p(yellow) - p(green)log}}_2 {\rm{p(green) - p(blue)log}}_2 {\rm{p(blue)}}  \cr 
  & \,\,\,\,\,\,\,\,\,\,\,\,\, =  - {1 \over 2}\log ({1 \over 2}) - {1 \over 2}\log ({1 \over 2}) - 0 - 0 = {1 \over 2} + {1 \over 2} + 0 + 0 = 1\,[\rm{bit}]  \cr 
  &  \cr}
$$

​												▶ 빨강,노랑 순서대로 (0, 1)로 인코딩 가능 (1 [bit])



#### Q4. 아래와 같이 상자 안에 8개의 공이 있고, 공의 색깔을 변수로 둘 때 엔트로피를 구하시오

![](./images/entropy_Q4.png)

#### solution) 

$$
\eqalign{
  & H[x]{\rm{ =  - p(red)log}}_2 {\rm{p(red) - p(yellow)log}}_2 {\rm{p(yellow) - p(green)log}}_2 {\rm{p(green) - p(blue)log}}_2 {\rm{p(blue)}}  \cr 
  & \,\,\,\,\,\,\,\,\,\,\,\,\, =  - 1\log (1) - 0 - 0 - 0 = 0\,[\rm{bit}]  \cr 
  &  \cr}
$$

​												▶ 엔트로피 없음 (한 사건에 확률이 몰려있음)

 



## KL(Kullback-Leibler) divergence

### 의미

- 실제모델 p에 대한 예측모델 q의 모델링 오류로 발생한 추가 엔트로피 비용
- 즉, 두 확률분포의 다름의 정도를 의미하며, relative entropy 라고도 불림

$$
KL(p||q) = \left\{ {\matrix{
   { - \sum\nolimits_x {p(x)\log _2 q(x) - ( - \sum\nolimits_x {p(x)\log _2 p(x)} ) =  - \sum\nolimits_x {p(x)\log _2 {{q(x)} \over {p(x)}}[\rm{bit}]} } \,\,\,\,\,\,\,\,\,\,({\rm{discrete}}\,\,{\rm{random}}\,\,{\rm{variable}})\,\,\,\,\,\,\,\,\,\,\,\,}  \cr 
   { - \int_x {p(x)\ln q(x)dx}  - ( - \int_x {p(x)\ln p(x)dx} ) =  - \int_x {p(x)\ln {{q(x)} \over {p(x)}}dx} \,\,[\rm{nat}]\,\,\,\,\,\,\,\,\,({\rm{continuous}}\,\,{\rm{random}}\,\,{\rm{variable}})}  \cr 

 } } \right.
$$

### 특징

- KL divergence는 예측모델이 실제모델과 일치할 경우 0값을 가지며, 이외는 모두 0보다 큼

$$
KL(p||q) \ge 0
$$

- 방향성 있음

$$
KL(p||q) \ne KL(q||p)
$$

![](./images/KL_property.png)

​												▶ KL(p||q) : KL divergence (left) > KL divergence (right)

​												▶ KL(q||p) : KL divergence (left) < KL divergence (right)



### 예제

#### Q. 아래와 같이 상자 안에 8개의 공이 있고, 색깔별로 균일하게 공이 있다고 예측 후 인코딩을 하였을 때 KL(p||q)를 구하시오

![](./images/entropy_Q2.png)

#### solution) 

- 예측모델의 최적 코딩 : (00, 01, 10, 11) 
- 실제모델의 최적 코딩 : (0, 10, 100, 101)
- 예측모델의 오류로 발생한 코딩 길이 추가비용 : 

$$
\eqalign{
  & KL(p||q) =  - \sum\nolimits_x {p(x)\log _2 q(x) - ( - \sum\nolimits_x {p(x)\log _2 p(x)} )}   \cr 
  & \,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\, = ({1 \over 2} \cdot 2 + {1 \over 4} \cdot 2 + {1 \over 8} \cdot 2 + {1 \over 8} \cdot 2) - ({1 \over 2} \cdot 1 + {1 \over 4} \cdot 2 + {1 \over 8} \cdot 3 + {1 \over 8} \cdot 3) = 2 - 1.75 = 0.25\,\,[{\rm{bit}}] \cr}
$$



## Cross entropy

### 의미

- 실제모델 p를 q로 예측 시 발생한 엔트로피

$$
- \sum\nolimits_x {p(x)\log _2 q(x)} \,\,\,[{\rm{bit}}]\,\,\,\,({\rm{discrete) }}\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,\,{\rm{   }} - \int_x {p(x)\ln p(x)dx} \,\,\,[{\rm{nat}}]\,\,\,\,({\rm{continuous}})
$$

- KL(p||q) 수식의 앞 항에 해당



### 참고: 학습 loss function으로 왜 KL divergence가 아닌 cross entropy를 사용하는가?

- 생성한 예측모델의 신경망은 q의 파라미터임
- KL(p||q) 를 q로 미분하면 p에 대한 term은 사라지므로, cross entropy의 미분 결과와 같음

