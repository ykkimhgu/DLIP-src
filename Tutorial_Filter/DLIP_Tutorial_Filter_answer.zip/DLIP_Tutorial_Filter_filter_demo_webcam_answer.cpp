/*------------------------------------------------------/
* Image Proccessing with Deep Learning
* OpenCV : Filter Demo - Video
* Created: 2021-Spring
------------------------------------------------------*/

#include <opencv2/opencv.hpp>
#include <iostream>

#define NORMAL		(int) 0
#define BLUR		(int) 1
#define GAUSSIAN	(int) 2
#define MEDIAN		(int) 3
#define FILTER_2D	(int) 4
#define LAPLACIAN	(int) 5

#define ESC			(int) 27

using namespace std;
using namespace cv;

int main()
{
	/*  open the video camera no.0  */
	VideoCapture cap(0);

	if (!cap.isOpened())	// if not success, exit the programm
	{
		cout << "Cannot open the video cam\n";
		return -1;
	}

	namedWindow("MyVideo", CV_WINDOW_AUTOSIZE);

	int key = 0;
	int kernel_size_laplacian = 3;
	int kernel_size = 3;
	int filter_type = NORMAL;

	int scale = 1;
	int delta = 0;
	int ddepth = CV_16S;

	int ddepth_2D = -1;
	Point anchor = Point(-1, -1);

	while (1)
	{
		Mat src, dst, kernel;

		/*  read a new frame from video  */
		bool bSuccess = cap.read(src);

		if (!bSuccess)	// if not success, break loop
		{
			cout << "Cannot find a frame from  video stream\n";
			break;
		}


		key = waitKey(30);
		if (key == ESC) // wait for 'ESC' press for 30ms. If 'ESC' is pressed, break loop
		{
			cout << "ESC key is pressed by user\n";
			break;
		}
		else if (key == 'b' || key == 'B')
		{
			filter_type = BLUR;			// blur
		}
		else if (key == 'g' || key == 'G')
		{
			filter_type = GAUSSIAN;		// gaussian
		}
		else if (key == 'm' || key == 'M')
		{
			filter_type = MEDIAN;		// blur
		}
		else if (key == 'f' || key == 'F')
		{
			filter_type = FILTER_2D;	// filter2D
		}
		else if (key == 'l' || key == 'L')
		{
			filter_type = LAPLACIAN;	// laplacian
		}
		else if (key == 'n' || key == 'N')
		{
			filter_type = NORMAL;
		}
		else if (key == 'u' || key == 'U')
		{
			kernel_size += 2;
		}
		else if (key == 'd' || key == 'D')
		{
			kernel_size -= 2;
		}

		// Box Filter
		if (kernel_size <= 3)		kernel_size = 3;
		else if (kernel_size >= 15) kernel_size = 15;

		kernel = Mat::ones(kernel_size, kernel_size, CV_32F) / (float)(kernel_size * kernel_size);


		if		(filter_type == BLUR)		blur(src, dst, Size(kernel_size, kernel_size), Point(-1, -1));

		else if (filter_type == GAUSSIAN)	GaussianBlur(src, dst, Size(kernel_size, kernel_size), 0, 0);

		else if (filter_type == MEDIAN)		medianBlur(src, dst, kernel_size);

		else if (filter_type == FILTER_2D)	filter2D(src, dst, ddepth_2D, kernel, anchor); // 3 by 3 ����� box filter

		else if (filter_type == LAPLACIAN) 
		{
			Laplacian(src, dst, ddepth, kernel_size_laplacian, scale, delta, BORDER_DEFAULT);
			src.convertTo(src, CV_16S);
			Mat result_laplcaian = src - dst;
			result_laplcaian.convertTo(result_laplcaian, CV_8U);
			dst = result_laplcaian;
		}

		else src.copyTo(dst);

		imshow("MyVideo", dst);

	}
	return 0;
}